#include<bits/stdc++.h>
using namespace std;

//  construct node for avl tree for height=h,count(for how many time word appears),word=w;left=l;right=r

struct node {
    string word;
    int count;
    int height;
    node* left;
    node* right;
};

// height function used in finding balence factor 


int height(node* n) {
    if (n == NULL)
        return 0;
    return n->height;
}

// balance factor(bf)=height of leftsubtree - right subtree it be(1,0,-1)
int balance(node* n) {
    if (n == NULL)
        return 0;
    return height(n->left) - height(n->right);
}

// createnode 
node* newNode(string w) {
    node* temp = new node();
    temp->word = w;
    temp->count = 1;
    temp->height = 1;
    temp->left = temp->right = NULL;
    return temp;
}
// right rotation function
node* rightrot(node* y) {
    node* x = y->left;
    node* t = x->right;
    x->right = y;
    y->left = t;
    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;
    return x;
}

// left rotation function
node* leftrot(node* x) {
    node* y = x->right;
    node* t = y->left;
    y->left = x;
    x->right = t;
    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;
    return y;
}

// clean word (remove symbols)

// this function i write with the help of llm to improve my code


string clean(string s) {
    string ans = "";
    for (int i = 0; i < s.length(); i++) {
        if (isalnum(s[i]))
            ans += tolower(s[i]);
    }
    return ans;
}

// insert function

node* insert(node* root, string w) {

    if (root == NULL)
        return newNode(w);

    if (w == root->word) {
        root->count++;
        return root;
    }

    if (w < root->word)
        root->left = insert(root->left, w);
    else
        root->right = insert(root->right, w);

    // update height
    root->height = 1 + max(height(root->left), height(root->right));

    int bf = balance(root);

    // LL
    if (bf > 1 && w < root->left->word)
        return rightrot(root);

    // RR
    if (bf < -1 && w > root->right->word)
        return leftrot(root);

    // LR
    if (bf > 1 && w > root->left->word) {
        root->left = leftrot(root->left);
        return rightrot(root);
    }

    // RL
    if (bf < -1 && w < root->right->word) {
        root->right = rightrot(root->right);
        return leftrot(root);
    }

    return root;
}

// inorder
void print(node* root) {
    if (root != NULL) {
        print(root->left);
        cout << root->word << " : " << root->count << endl;
        print(root->right);
    }
}

int main() {
    string filename;
    cout << "enter file name: ";
    cin >> filename;

    ifstream f(filename);

    if (!f) {
        cout << "file not found"<<endl;
        return 0;
    }

    node* root = NULL;
    string w;

    while (f >> w) {
        w = clean(w);
        if (w != "")
            root = insert(root, w);
    }

    cout << "word count:"<<endl;
    print(root);

    return 0;
}

